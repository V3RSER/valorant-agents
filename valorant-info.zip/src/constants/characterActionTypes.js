export const character = {
  RESPONSE: "character/RESPONSE",
};

export default {
  character,
};
