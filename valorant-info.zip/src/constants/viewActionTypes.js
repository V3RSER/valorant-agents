export const view = {
  LOADING: "view/LOADING",
  LOADED: "view/LOADED",
};

export default {
  view,
};
