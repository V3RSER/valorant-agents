import CharacterList from "./compontents/CharacterList";

function App() {
  return (
    <div className="App"> 
      <div className="card-deck">
        
        {/* 
        <CharacterCard
          image={
            "https://media.valorant-api.com/agents/f94c3b30-42be-e959-889c-5aa313dba261/fullportraitv2.png"
          }
          background={
            "https://media.valorant-api.com/agents/f94c3b30-42be-e959-889c-5aa313dba261/background.png"
          }
          icon={
            "https://media.valorant-api.com/agents/f94c3b30-42be-e959-889c-5aa313dba261/displayicon.png"
          }
          name={"Raze"}
          role={{
            name: "Duelista",
            icon: "https://media.valorant-api.com/agents/roles/dbe8757e-9e92-4ed4-b39f-9dfc589691d4/displayicon.png",
          }}
        />
        */}
        <CharacterList/>
  
      </div>
    </div>
  );
}

export default App;
